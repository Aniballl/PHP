<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inicio</title>
</head>
<body>
<?php
	include 'header.php';
?>

    <img src="img/abundante-coleccion-libros-antiguos-estantes-madera-generados-ia.jpg" alt="Libreria fondo"
         class="encabezado">
    <div class="lista">
        <div class="columna">
            <img src="img/featured_image_cuando_las_librerias_se_convierten_en_lugares_de_culto.jpg"
                  alt="Comprar">
            <h1>Comprar online y recoger en tienda</h1>
            <p><b>Realiza tu pedido en nuestra web. En el proceso de compra, elige la forma de envío "Recogida en
                    librería" e indícanos tu código postal para que elijas la librería más cercana*</b>Te enviaremos
                un sms o e-mail cuando tu pedido esté listo para recoger en la librería que hayas seleccionado.<br>
                Será necesario presentar el DNI junto al sms o e-mail de aviso de recogida. Si lo va a recoger otra persona, reenvía ese sms o e-mail como forma de autorización para que pueda enseñarlo en el momento de la recogida.</p>
        </div>
        <div class="columna1">
            <img src="img/chica-segura-sentada-libros.jpg" alt="Niña leyendo">
            <h1>Lectura Infantil</h1>
            <p><b>La importancia de los cuentos cortos para niños y niñas</b>La tradición de leer cuentos está tan arraigada que ni siquiera el frenético ritmo de vida que llevamos va a poder con ella. Aunque es cierto que, en ocasiones, nos resulta difícil, puesto que llegamos tarde y cansados o cansadas a casa, pero no debemos dejar de hacerlo.</p>
        </div>
        <div class="columna">
            <img src="img/mujer-sonriente-camisa-leyendo-libro.jpg" alt="Suscribete">
            <h1>Suscribirse</h1>
            <p><b>¿Eres amante de la lectura? ¿Buscas los mejores precios y ventajas en libros? Únete gratis al Programa y hazte Socio de Casa del Libro. Es gratis y solo tardarás un minuto. Disfruta más del mundo de la cultura, por mucho menos.</b>Premiamos todas las compras de nuestros Socios y Socias. El Programa cuenta con 3 niveles: Original, Genuino y Leyenda. Empezarás desde el nivel Original y a medida que vayas realizando compras irás subiendo de nivel y obteniendo más ofertas y ventajas.</p>
        </div>
        </div>
    </div>

<?php
	include 'footer.php';
?>

</body>
</html>