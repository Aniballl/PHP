<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Muestra</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <ul class="menu">
        <img src="img/Favicon.png" class="favicon">
        <li class="lista"><a href="index.php" class="menuItem">Inicio</a> </li>
        <li class="lista"><a href="tienda.php" class="menuItem">Tienda</a> </li>
        <li class="lista"><a href="contacto.php" class="menuItem">Contacto</a></li>
        <img src="img/Favicon.png" class="favicon">
    </ul>
</div>

